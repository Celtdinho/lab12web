<?php
$db = new Database();
$form = new Form("/lab11_php_oop/artikel/tambah", "Simpan");

if ($_POST) {
    $db->insert("artikel", [
        "judul" => $_POST['judul'],
        "isi" => $_POST['isi']
    ]);

    echo "<script>alert('Berhasil disimpan');location.href='/lab11_php_oop/artikel/index';</script>";
}
?>

<h2>Tambah Artikel</h2>

<?php
$form->addField("judul", "Judul Artikel");
$form->addField("isi", "Isi Artikel", "textarea");
$form->displayForm();
?>
