<?php
$db = new Database();
$data = $db->query("SELECT * FROM artikel ORDER BY id DESC");
?>

<h2>Data Artikel</h2>

<table border="1" width="100%">
<tr>
    <th>ID</th>
    <th>Judul</th>
    <th>Aksi</th>
</tr>

<?php while ($row = $data->fetch_assoc()) { ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['judul'] ?></td>
    <td>
        <a href="/lab11_php_oop/artikel/ubah?id=<?= $row['id'] ?>">Ubah</a>
    </td>
</tr>
<?php } ?>

</table>
