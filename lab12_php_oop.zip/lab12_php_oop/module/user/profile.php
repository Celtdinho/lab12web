<?php
// Proteksi: hanya user login
if (!isset($_SESSION['is_login'])) {
    header("Location: /lab11_php_oop/user/login");
    exit;
}

$db = new Database();
$message = "";

// Ambil data user login
$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username='$username' LIMIT 1";
$result = $db->query($sql);
$user = $result->fetch_assoc();

// Proses ganti password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass_lama = $_POST['password_lama'];
    $pass_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if (!password_verify($pass_lama, $user['password'])) {
        $message = "Password lama salah!";
    } elseif ($pass_baru !== $konfirmasi) {
        $message = "Konfirmasi password tidak cocok!";
    } else {
        $hash = password_hash($pass_baru, PASSWORD_DEFAULT);
        $db->update("users", ['password' => $hash], "username='$username'");
        $message = "Password berhasil diperbarui!";
    }
}
?>

<h2>Profil User</h2>

<div class="card">

    <?php if ($message): ?>
        <div class="alert-success"><?= $message ?></div>
    <?php endif; ?>

    <p><strong>Nama:</strong> <?= htmlspecialchars($user['nama']) ?></p>
    <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>

    <hr>

    <h3>Ganti Password</h3>

    <form method="POST">
        <label>Password Lama</label>
        <input type="password" name="password_lama" required>

        <label>Password Baru</label>
        <input type="password" name="password_baru" required>

        <label>Konfirmasi Password Baru</label>
        <input type="password" name="konfirmasi_password" required>

        <button type="submit">Simpan Perubahan</button>
    </form>
</div>
