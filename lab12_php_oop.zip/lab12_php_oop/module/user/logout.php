<?php
session_destroy();
header("Location: /lab11_php_oop/user/login");
exit;
