<?php
// JANGAN session_start() — sudah di index.php

require_once __DIR__ . '/../../class/database.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM users WHERE username='$username' LIMIT 1";
    $result = $db->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['is_login'] = true;
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama'] = $user['nama'];

            header("Location: /lab11_php_oop/home/index");
            exit;
        }
    }
    $message = "Username atau password salah!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>


    <link rel="stylesheet" href="/lab11_php_oop/assets/css/style.css">
</head>
<body>

<div class="card" style="margin:100px auto;">
    <h2 style="text-align:center;">Login</h2>

    <?php if ($message): ?>
        <div class="alert-error"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
