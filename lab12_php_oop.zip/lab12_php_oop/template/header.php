<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Framework Modular</title>
    <link rel="stylesheet" href="/lab11_php_oop/assets/css/style.css">
</head>
<body>

<div class="header">
    <h2>Framework Modular</h2>
</div>
