<div class="sidebar">
    <a href="/lab11_php_oop/home/index">Home</a>

    <?php if (isset($_SESSION['is_login'])): ?>
        <a href="/lab11_php_oop/artikel/index">Artikel</a>
        <a href="/lab11_php_oop/user/profile">Profil</a>
        <a href="/lab11_php_oop/user/logout">Logout</a>
    <?php else: ?>
        <a href="/lab11_php_oop/user/login">Login</a>
    <?php endif; ?>
</div>

<div class="content">
